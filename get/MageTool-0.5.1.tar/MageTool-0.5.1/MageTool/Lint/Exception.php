<?php
class MageTool_Lint_Exception extends Exception
{
    
}