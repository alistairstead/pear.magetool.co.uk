<?php

class MageTool_Tool_Provider_Exception extends Zend_Exception
{

}