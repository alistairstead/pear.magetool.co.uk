<?php

class MageTool_Tool_MageApp_Exception extends Zend_Exception
{

}