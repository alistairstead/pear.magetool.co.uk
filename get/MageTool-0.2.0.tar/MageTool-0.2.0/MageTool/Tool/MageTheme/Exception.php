<?php

/**
 * @see Zend_Exception
 */
require_once 'Zend/Exception.php';

class MageTool_Tool_MageTheme_Exception extends Zend_Exception
{

}